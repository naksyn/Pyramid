Python Module Distribution Utilities extracted from the Python Standard Library

Synchronizing
=============

This project is no longer kept in sync with the code still in stdlib, which is deprecated and scheduled for removal.

To Setuptools
-------------

Simply merge the changes directly into setuptools' repo.
