from .winproxy.apiproxy import is_implemented, get_target, resolve
from .winproxy.error import WinproxyError, ExportNotFound
from .winproxy.apis import * # Import all functions