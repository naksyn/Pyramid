#from .advapi32 import *  ### BYPASS ALL OF THE COMMENTS BELOW
#from .cfgmgr32 import *  ### BYPASS
#from .crypt32 import *
#from .cryptui import *
#from .dbghelp import *
#from .dnsapi import *
#from .iphlpapi import *
from windows.winproxy.apis.kernel32 import *
#from .ktmw32 import *
#from .ntdll import *
#from .netapi32 import *
#from .ole32 import *
#from .oleaut32 import *
#from .oleacc import *
#from .psapi import *
#from .setupapi import *
#from .shell32 import *
#from .shlwapi import *
#from .tdh import *
#from .user32 import *
#from .version import *
#from .virtdisk import *
#from .wevtapi import *
#from .winhttp import *
#from .wininet import *
#from .wintrust import *
#from .ws2_32 import *