import sys

# https://www.python.org/dev/peps/pep-0396/
__version__ = '1.16.0'
