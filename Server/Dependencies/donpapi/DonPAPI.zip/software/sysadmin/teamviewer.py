'''
https://whynotsecurity.com/blog/teamviewer/
TL;DR: TeamViewer stored user passwords encrypted with AES-128-CBC with they key of
key:0602000000a400005253413100040000
IV:0100010067244F436E6762F25EA8D704


'''