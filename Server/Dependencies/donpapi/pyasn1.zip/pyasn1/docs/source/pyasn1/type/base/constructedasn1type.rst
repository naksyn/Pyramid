
.. _base.ConstructedAsn1Type:

.. |ASN.1| replace:: ConstructedAsn1Type

|ASN.1| type
------------

.. autoclass:: pyasn1.type.base.ConstructedAsn1Type(tagSet=TagSet(), subtypeSpec=ConstraintsIntersection(), componentType=None)
   :members: isSameTypeWith, isSuperTypeOf, tagSet, effectiveTagSet, tagMap, subtypeSpec
