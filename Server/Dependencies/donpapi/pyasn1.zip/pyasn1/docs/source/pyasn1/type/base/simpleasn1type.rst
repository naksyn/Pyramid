
.. _base.SimpleAsn1Type:

.. |ASN.1| replace:: SimpleAsn1Type

|ASN.1| type
------------

.. autoclass:: pyasn1.type.base.SimpleAsn1Type(value=NoValue(), tagSet=TagSet(), subtypeSpec=ConstraintsIntersection())
   :members: isValue, isSameTypeWith, isSuperTypeOf, tagSet, effectiveTagSet, tagMap, subtypeSpec
