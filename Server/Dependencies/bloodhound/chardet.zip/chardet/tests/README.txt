These test feeds were downloaded from random sites while I was developing the
Universal Encoding Detector. Each feed is copyright its respective publisher.

Contributions of openly-licensed test data would be graciously received at
https://github.com/erikrose/chardet
