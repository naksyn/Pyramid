"""Python filesystem abstraction layer.
"""

__import__("pkg_resources").declare_namespace(__name__)  # type: ignore

from fs.base import FS
from fs import path
from fs._fscompat import fsdecode, fsencode
from fs._version import __version__
from fs.enums import ResourceType, Seek
from fs.opener import open_fs

__all__ = ["__version__", "ResourceType", "Seek", "open_fs"]
