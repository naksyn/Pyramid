"""
fs.opener
=========

Open filesystems via a URI.

There are occasions when you want to specify a filesystem from the command line
or in a config file. This module enables that functionality, and can return an
FS object given a filesystem specification in a URI-like syntax (inspired by
the syntax of http://commons.apache.org/vfs/filesystems.html).

The `OpenerRegistry` class maps the protocol (file, ftp etc.) on to an Opener
object, which returns an appropriate filesystem object and path.  You can
create a custom opener registry that opens just the filesystems you require, or
use the opener registry defined here (also called `opener`) that can open any
supported filesystem.

The `parse` method of an `OpenerRegsitry` object returns a tuple of an FS
object a path. Here's an example of how to use the default opener registry::

    >>> from fs.opener import opener
    >>> opener.parse('ftp://ftp.mozilla.org/pub')
    (<fs.ftpfs.FTPFS object at 0x96e66ec>, u'pub')

You can use use the `opendir` method, which just returns an FS object. In the
example above, `opendir` will return a FS object for the directory `pub`::

    >>> opener.opendir('ftp://ftp.mozilla.org/pub')
    <SubFS: <FTPFS ftp.mozilla.org>/pub>

If you are just interested in a single file, use the `open` method of a registry
which returns a file-like object, and has the same signature as FS objects and
the `open` builtin::

    >>> opener.open('ftp://ftp.mozilla.org/pub/README')
    <fs.ftpfs._FTPFile object at 0x973764c>

The `opendir` and `open` methods can also be imported from the top-level of
this module for sake of convenience.  To avoid shadowing the builtin `open`
method, they are named `fsopendir` and `fsopen`. Here's how you might import
them::

    from fs.opener import fsopendir, fsopen


"""

__all__ = ['OpenerError',
           'NoOpenerError',
           'OpenerRegistry',
           'opener',
           'fsopen',
           'fsopendir',
           'OpenerRegistry',
           'Opener',
           'OSFSOpener',
           'ZipOpener',
           'RPCOpener',
           'FTPOpener',
           'SFTPOpener',
           'MemOpener',
           'DebugOpener',
           'TempOpener',
           'S3Opener',
           'TahoeOpener',
           'DavOpener',
           'HTTPOpener']

from fs.path import pathsplit, join, iswildcard, normpath
#from fs.osfs import OSFS
#from fs.filelike import FileWrapper
from os import getcwd
import os.path
import re
import urllib.parse
from six import BytesIO as _StringIO

class FileLikeBase(object):
    """Base class for implementing file-like objects.
    This class takes a lot of the legwork out of writing file-like objects
    with a rich interface.  It implements the higher-level file-like methods
    on top of five primitive methods: _read, _write, _seek, _tell and
    _truncate. See their docstrings for precise details on how these methods
    behave.
    Subclasses then need only implement some subset of these methods for
    rich file-like interface compatibility.  They may of course override
    other methods as desired.
    The class is missing the following attributes and methods, which don't
    really make sense for anything but real files:
        * fileno()
        * isatty()
        * encoding
        * mode
        * name
        * newlines
    Unlike standard file objects, all read methods share the same buffer
    and so can be freely mixed (e.g. read(), readline(), next(), ...).
    This class understands and will accept the following mode strings,
    with any additional characters being ignored:
        * r    - open the file for reading only.
        * r+   - open the file for reading and writing.
        * r-   - open the file for streamed reading; do not allow seek/tell.
        * w    - open the file for writing only; create the file if
                 it doesn't exist; truncate it to zero length.
        * w+   - open the file for reading and writing; create the file
                 if it doesn't exist; truncate it to zero length.
        * w-   - open the file for streamed writing; do not allow seek/tell.
        * a    - open the file for writing only; create the file if it
                 doesn't exist; place pointer at end of file.
        * a+   - open the file for reading and writing; create the file
                 if it doesn't exist; place pointer at end of file.
    These are mostly standard except for the "-" indicator, which has
    been added for efficiency purposes in cases where seeking can be
    expensive to simulate (e.g. compressed files).  Note that any file
    opened for both reading and writing must also support seeking.
    """

    def __init__(self,bufsize=1024*64):
        """FileLikeBase Constructor.
        The optional argument 'bufsize' specifies the number of bytes to
        read at a time when looking for a newline character.  Setting this to
        a larger number when lines are long should improve efficiency.
        """
        super(FileLikeBase, self).__init__()
        # File-like attributes
        self.closed = False
        self.softspace = 0
        # Our own attributes
        self._bufsize = bufsize  # buffer size for chunked reading
        self._rbuffer = None     # data that's been read but not returned
        self._wbuffer = None     # data that's been given but not written
        self._sbuffer = None     # data between real & apparent file pos
        self._soffset = 0        # internal offset of file pointer

    #
    #  The following five methods are the ones that subclasses are expected
    #  to implement.  Carefully check their docstrings.
    #

    def _read(self,sizehint=-1):
        """Read approximately <sizehint> bytes from the file-like object.
        This method is to be implemented by subclasses that wish to be
        readable.  It should read approximately <sizehint> bytes from the
        file and return them as a string.  If <sizehint> is missing or
        less than or equal to zero, try to read all the remaining contents.
        The method need not guarantee any particular number of bytes -
        it may return more bytes than requested, or fewer.  If needed the
        size hint may be completely ignored.  It may even return an empty
        string if no data is yet available.
        Because of this, the method must return None to signify that EOF
        has been reached.  The higher-level methods will never indicate EOF
        until None has been read from _read().  Once EOF is reached, it
        should be safe to call _read() again, immediately returning None.
        """
        raise NotReadableError("Object not readable")

    def _write(self,string,flushing=False):
        """Write the given string to the file-like object.
        This method must be implemented by subclasses wishing to be writable.
        It must attempt to write as much of the given data as possible to the
        file, but need not guarantee that it is all written.  It may return
        None to indicate that all data was written, or return as a string any
        data that could not be written.
        If the keyword argument 'flushing' is true, it indicates that the
        internal write buffers are being flushed, and *all* the given data
        is expected to be written to the file. If unwritten data is returned
        when 'flushing' is true, an IOError will be raised.
        """
        raise NotWritableError("Object not writable")

    def _seek(self,offset,whence):
        """Set the file's internal position pointer, approximately.
        This method should set the file's position to approximately 'offset'
        bytes relative to the position specified by 'whence'.  If it is
        not possible to position the pointer exactly at the given offset,
        it should be positioned at a convenient *smaller* offset and the
        file data between the real and apparent position should be returned.
        At minimum, this method must implement the ability to seek to
        the start of the file, i.e. offset=0 and whence=0.  If more
        complex seeks are difficult to implement then it may raise
        NotImplementedError to have them simulated (inefficiently) by
        the higher-level machinery of this class.
        """
        raise NotSeekableError("Object not seekable")

    def _tell(self):
        """Get the location of the file's internal position pointer.
        This method must be implemented by subclasses that wish to be
        seekable, and must return the position of the file's internal
        pointer.
        Due to buffering, the position seen by users of this class
        (the "apparent position") may be different to the position
        returned by this method (the "actual position").
        """
        raise NotSeekableError("Object not seekable")

    def _truncate(self,size):
        """Truncate the file's size to <size>.
        This method must be implemented by subclasses that wish to be
        truncatable.  It must truncate the file to exactly the given size
        or fail with an IOError.
        Note that <size> will never be None; if it was not specified by the
        user then it is calculated as the file's apparent position (which may
        be different to its actual position due to buffering).
        """
        raise NotTruncatableError("Object not truncatable")

    #
    #  The following methods provide the public API of the filelike object.
    #  Subclasses shouldn't need to mess with these (except perhaps for
    #  close() and flush())
    #

    def _check_mode(self,mode,mstr=None):
        """Check whether the file may be accessed in the given mode.
        'mode' must be one of "r" or "w", and this function returns False
        if the file-like object has a 'mode' attribute, and it does not
        permit access in that mode.  If there is no 'mode' attribute,
        it defaults to "r+".
        If seek support is not required, use "r-" or "w-" as the mode string.
        To check a mode string other than self.mode, pass it in as the
        second argument.
        """
        if mstr is None:
            try:
                mstr = self.mode
            except AttributeError:
                mstr = "r+"
        if "+" in mstr:
            return True
        if "-" in mstr and "-" not in mode:
            return False
        if "r" in mode:
            if "r" not in mstr:
                return False
        if "w" in mode:
            if "w" not in mstr and "a" not in mstr:
                return False
        return True

    def _assert_mode(self,mode,mstr=None):
        """Check whether the file may be accessed in the given mode.
        This method is equivalent to _check_assert(), but raises IOError
        instead of returning False.
        """
        if mstr is None:
            try:
                mstr = self.mode
            except AttributeError:
                mstr = "r+"
        if "+" in mstr:
            return True
        if "-" in mstr and "-" not in mode:
            raise NotSeekableError("File does not support seeking.")
        if "r" in mode:
            if "r" not in mstr:
                raise NotReadableError("File not opened for reading")
        if "w" in mode:
            if "w" not in mstr and "a" not in mstr:
                raise NotWritableError("File not opened for writing")
        return True

    def flush(self):
        """Flush internal write buffer, if necessary."""
        if self.closed:
            raise IOError("File has been closed")
        if self._check_mode("w-") and self._wbuffer is not None:
            buffered = b("")
            if self._sbuffer:
                buffered = buffered + self._sbuffer
                self._sbuffer = None
            buffered = buffered + self._wbuffer
            self._wbuffer = None
            leftover = self._write(buffered,flushing=True)
            if leftover and not isinstance(leftover, int):
                raise IOError("Could not flush write buffer.")

    def close(self):
        """Flush write buffers and close the file.
        The file may not be accessed further once it is closed.
        """
        #  Errors in subclass constructors can cause this to be called without
        #  having called FileLikeBase.__init__().  Since we need the attrs it
        #  initializes in cleanup, ensure we call it here.
        if not hasattr(self,"closed"):
            FileLikeBase.__init__(self)
        if not self.closed:
            self.flush()
            self.closed = True

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self,exc_type,exc_val,exc_tb):
        self.close()
        return False

    def next(self):
        """next() method complying with the iterator protocol.
        File-like objects are their own iterators, with each call to
        next() returning subsequent lines from the file.
        """
        ln = self.readline()
        if ln == b(""):
            raise StopIteration()
        return ln

    def __iter__(self):
        return self

    def truncate(self,size=None):
        """Truncate the file to the given size.
        If <size> is not specified or is None, the current file position is
        used.  Note that this method may fail at runtime if the underlying
        filelike object is not truncatable.
        """
        if "-" in getattr(self,"mode",""):
            raise NotTruncatableError("File is not seekable, can't truncate.")
        if self._wbuffer:
            self.flush()
        if size is None:
            size = self.tell()
        self._truncate(size)

    def seek(self,offset,whence=0):
        """Move the internal file pointer to the given location."""
        if whence > 2 or whence < 0:
            raise ValueError("Invalid value for 'whence': " + str(whence))
        if "-" in getattr(self,"mode",""):
            raise NotSeekableError("File is not seekable.")
        # Ensure that there's nothing left in the write buffer
        if self._wbuffer:
            self.flush()
        # Adjust for any data left in the read buffer
        if whence == 1 and self._rbuffer:
            offset = offset - len(self._rbuffer)
        self._rbuffer = None
        # Adjust for any discrepancy in actual vs apparent seek position
        if whence == 1:
            if self._sbuffer:
                offset = offset + len(self._sbuffer)
            if self._soffset:
                offset = offset + self._soffset
        self._sbuffer = None
        self._soffset = 0
        # Shortcut the special case of staying put.
        # As per posix, this has already cases the buffers to be flushed.
        if offset == 0 and whence == 1:
            return
        # Catch any failed attempts to read while simulating seek
        try:
            # Try to do a whence-wise seek if it is implemented.
            sbuf = None
            try:
                sbuf = self._seek(offset,whence)
            except NotImplementedError:
                # Try to simulate using an absolute seek.
                try:
                    if whence == 1:
                        offset = self._tell() + offset
                    elif whence == 2:
                        if hasattr(self,"size"):
                            offset = self.size + offset
                        else:
                            self._do_read_rest()
                            offset = self.tell() + offset
                    else:
                        # absolute seek already failed, don't try again
                        raise NotImplementedError
                    sbuf = self._seek(offset,0)
                except NotImplementedError:
                    # Simulate by reseting to start
                    self._seek(0,0)
                    self._soffset = offset
            finally:
                self._sbuffer = sbuf
        except NotReadableError:
            raise NotSeekableError("File not readable, can't simulate seek")

    def tell(self):
        """Determine current position of internal file pointer."""
        # Need to adjust for unread/unwritten data in buffers
        pos = self._tell()
        if self._rbuffer:
            pos = pos - len(self._rbuffer)
        if self._wbuffer:
            pos = pos + len(self._wbuffer)
        if self._sbuffer:
            pos = pos + len(self._sbuffer)
        if self._soffset:
            pos = pos + self._soffset
        return pos

    def read(self,size=-1):
        """Read at most 'size' bytes from the file.
        Bytes are returned as a string.  If 'size' is negative, zero or
        missing, the remainder of the file is read.  If EOF is encountered
        immediately, the empty string is returned.
        """
        if self.closed:
            raise IOError("File has been closed")
        self._assert_mode("r-")
        return self._do_read(size)

    def _do_read(self,size):
        """Private method to read from the file.
        This method behaves the same as self.read(), but skips some
        permission and sanity checks.  It is intended for use in simulating
        seek(), where we may want to read (and discard) information from
        a file not opened in read mode.
        Note that this may still fail if the file object actually can't
        be read from - it just won't check whether the mode string gives
        permission.
        """
        # If we were previously writing, ensure position is correct
        if self._wbuffer is not None:
            self.seek(0,1)
        # Discard any data that should have been seeked over
        if self._sbuffer:
            s = len(self._sbuffer)
            self._sbuffer = None
            self.read(s)
        elif self._soffset:
            s = self._soffset
            self._soffset = 0
            while s > self._bufsize:
                self._do_read(self._bufsize)
                s -= self._bufsize
            self._do_read(s)
        # Should the entire file be read?
        if size < 0:
            if self._rbuffer:
                data = [self._rbuffer]
            else:
                data = []
            self._rbuffer = b("")
            newData = self._read()
            while newData is not None:
                data.append(newData)
                newData = self._read()
            output = b("").join(data)
        # Otherwise, we need to return a specific amount of data
        else:
            if self._rbuffer:
                newData = self._rbuffer
                data = [newData]
            else:
                newData = b("")
                data = []
            sizeSoFar = len(newData)
            while sizeSoFar < size:
                newData = self._read(size-sizeSoFar)
                if not newData:
                    break
                data.append(newData)
                sizeSoFar += len(newData)
            data = b("").join(data)
            if sizeSoFar > size:
                # read too many bytes, store in the buffer
                self._rbuffer = data[size:]
                data = data[:size]
            else:
                self._rbuffer = b("")
            output = data
        return output

    def _do_read_rest(self):
        """Private method to read the file through to EOF."""
        data = self._do_read(self._bufsize)
        while data != b(""):
            data = self._do_read(self._bufsize)

    def readline(self,size=-1):
        """Read a line from the file, or at most <size> bytes."""
        bits = []
        indx = -1
        sizeSoFar = 0
        while indx == -1:
            nextBit = self.read(self._bufsize)
            bits.append(nextBit)
            sizeSoFar += len(nextBit)
            if not nextBit:
                break
            if size > 0 and sizeSoFar >= size:
                break
            indx = nextBit.find(b("\n"))
        # If not found, return whole string up to <size> length
        # Any leftovers are pushed onto front of buffer
        if indx == -1:
            data = b("").join(bits)
            if size > 0 and sizeSoFar > size:
                extra = data[size:]
                data = data[:size]
                self._rbuffer = extra + self._rbuffer
            return data
        # If found, push leftovers onto front of buffer
        # Add one to preserve the newline in the return value
        indx += 1
        extra = bits[-1][indx:]
        bits[-1] = bits[-1][:indx]
        self._rbuffer = extra + self._rbuffer
        return b("").join(bits)

    def readlines(self,sizehint=-1):
        """Return a list of all lines in the file."""
        return [ln for ln in self]

    def xreadlines(self):
        """Iterator over lines in the file - equivalent to iter(self)."""
        return iter(self)

    def write(self,string):
        """Write the given string to the file."""
        if self.closed:
            raise IOError("File has been closed")
        self._assert_mode("w-")
        # If we were previously reading, ensure position is correct
        if self._rbuffer is not None:
            self.seek(0, 1)
        # If we're actually behind the apparent position, we must also
        # write the data in the gap.
        if self._sbuffer:
            string = self._sbuffer + string
            self._sbuffer = None
        elif self._soffset:
            s = self._soffset
            self._soffset = 0
            try:
                string = self._do_read(s) + string
            except NotReadableError:
                raise NotSeekableError("File not readable, could not complete simulation of seek")
            self.seek(0, 0)
        if self._wbuffer:
            string = self._wbuffer + string
        leftover = self._write(string)
        if leftover is None or isinstance(leftover, int):
            self._wbuffer = b("")
            return len(string) - (leftover or 0)
        else:
            self._wbuffer = leftover
            return len(string) - len(leftover)

    def writelines(self,seq):
        """Write a sequence of lines to the file."""
        for ln in seq:
            self.write(ln)

class FileWrapper(FileLikeBase):
    """Base class for objects that wrap a file-like object.
    This class provides basic functionality for implementing file-like
    objects that wrap another file-like object to alter its functionality
    in some way.  It takes care of house-keeping duties such as flushing
    and closing the wrapped file.
    Access to the wrapped file is given by the attribute wrapped_file.
    By convention, the subclass's constructor should accept this as its
    first argument and pass it to its superclass's constructor in the
    same position.
    This class provides a basic implementation of _read() and _write()
    which just calls read() and write() on the wrapped object.  Subclasses
    will probably want to override these.
    """

    _append_requires_overwrite = False

    def __init__(self,wrapped_file,mode=None):
        """FileWrapper constructor.
        'wrapped_file' must be a file-like object, which is to be wrapped
        in another file-like object to provide additional functionality.
        If given, 'mode' must be the access mode string under which
        the wrapped file is to be accessed.  If not given or None, it
        is looked up on the wrapped file if possible.  Otherwise, it
        is not set on the object.
        """
        # This is used for working around flush/close inefficiencies
        self.__closing = False
        super(FileWrapper,self).__init__()
        self.wrapped_file = wrapped_file
        if mode is None:
            self.mode = getattr(wrapped_file,"mode","r+")
        else:
            self.mode = mode
        self._validate_mode()
        # Copy useful attributes of wrapped_file
        if hasattr(wrapped_file,"name"):
            self.name = wrapped_file.name
        # Respect append-mode setting
        if "a" in self.mode:
            if self._check_mode("r"):
                self.wrapped_file.seek(0)
            self.seek(0,2)

    def _validate_mode(self):
        """Check that various file-mode conditions are satisfied."""
        #  If append mode requires overwriting the underlying file,
        #  if must not be opened in append mode.
        if self._append_requires_overwrite:
            if self._check_mode("w"):
                if "a" in getattr(self.wrapped_file,"mode",""):
                    raise ValueError("Underlying file can't be in append mode")

    def __del__(self):
        #  Errors in subclass constructors could result in this being called
        #  without invoking FileWrapper.__init__.  Establish some simple
        #  invariants to prevent errors in this case.
        if not hasattr(self,"wrapped_file"):
            self.wrapped_file = None
        if not hasattr(self,"_FileWrapper__closing"):
            self.__closing = False
        #  Close the wrapper and the underlying file independently, so the
        #  latter is still closed on cleanup even if the former errors out.
        try:
            if FileWrapper is not None:
                super(FileWrapper,self).close()
        finally:
            if hasattr(getattr(self,"wrapped_file",None),"close"):
                self.wrapped_file.close()

    def close(self):
        """Close the object for reading/writing."""
        #  The superclass implementation of this will call flush(),
        #  which calls flush() on our wrapped object.  But we then call
        #  close() on it, which will call its flush() again!  To avoid
        #  this inefficiency, our flush() will not flush the wrapped
        #  file when we're closing.
        if not self.closed:
            self.__closing = True
            super(FileWrapper,self).close()
            if hasattr(self.wrapped_file,"close"):
                self.wrapped_file.close()

    def flush(self):
        """Flush the write buffers of the file."""
        super(FileWrapper,self).flush()
        if not self.__closing and hasattr(self.wrapped_file,"flush"):
            self.wrapped_file.flush()

    def _read(self,sizehint=-1):
        data = self.wrapped_file.read(sizehint)
        if data == b(""):
            return None
        return data

    def _write(self,string,flushing=False):
        self.wrapped_file.write(string)

    def _seek(self,offset,whence):
        self.wrapped_file.seek(offset,whence)

    def _tell(self):
        return self.wrapped_file.tell()

    def _truncate(self,size):
        return self.wrapped_file.truncate(size)


class StringIO(FileWrapper):
    """StringIO wrapper that more closely matches standard file behavior.
    This is a simple compatibility wrapper around the native StringIO class
    which fixes some corner-cases of its behavior.  Specifically:
        * adding __enter__ and __exit__ methods
        * having truncate(size) zero-fill when growing the file
    """

    def __init__(self,data=None,mode=None):
        wrapped_file = _StringIO()
        if data is not None:
            wrapped_file.write(data)
            wrapped_file.seek(0)
        super(StringIO,self).__init__(wrapped_file,mode)

    def getvalue(self):
        return self.wrapped_file.getvalue()

    def _truncate(self,size):
        pos = self.wrapped_file.tell()
        self.wrapped_file.truncate(size)
        curlen = len(self.wrapped_file.getvalue())
        if size > curlen:
            self.wrapped_file.seek(curlen)
            try:
                self.wrapped_file.write(b("\x00")*(size-curlen))
            finally:
                self.wrapped_file.seek(pos)

class OpenerError(Exception):
    """The base exception thrown by openers"""
    pass

class NoOpenerError(OpenerError):
    """Thrown when there is no opener for the given protocol"""
    pass

def _expand_syspath(path):
    if path is None:
        return path
    if path.startswith('\\\\?\\'):
        path = path[4:]
    path = os.path.expanduser(os.path.expandvars(path))
    path = os.path.normpath(os.path.abspath(path))
    return path

def _parse_credentials(url):
    scheme = None
    if '://' in url:
        scheme, url = url.split('://', 1)
    username = None
    password = None
    if '@' in url:
        credentials, url = url.split('@', 1)
        if ':' in credentials:
            username, password = credentials.split(':', 1)
        else:
            username = credentials
    if scheme is not None:
        url = '%s://%s' % (scheme, url)
    return username, password, url

def _parse_name(fs_name):
    if '#' in fs_name:
        fs_name, fs_name_params = fs_name.split('#', 1)
        return fs_name, fs_name_params
    else:
        return fs_name, None

def _split_url_path(url):
    if '://' not in url:
        url = 'http://' + url
    scheme, netloc, path, _params, _query, _fragment = urllib.parse(url)
    url = '%s://%s' % (scheme, netloc)
    return url, path


def _FSClosingFile(fs, file_object, mode):
    original_close = file_object.close

    def close():
        try:
            fs.close()
        except:
            pass
        return original_close()
    file_object.close = close
    return file_object


class OpenerRegistry(object):

    """An opener registry that  stores a number of opener objects used to parse FS URIs"""

    re_fs_url = re.compile(r'''
^
(.*?)
:\/\/

(?:
(?:(.*?)@(.*?))
|(.*?)
)

(?:
!(.*?)$
)*$
''', re.VERBOSE)


    def __init__(self, openers=[]):
        self.registry = {}
        self.openers = {}
        self.default_opener = 'memfs'
        for opener in openers:
            self.add(opener)

    @classmethod
    def split_segments(self, fs_url):
        match = self.re_fs_url.match(fs_url)
        return match

    def get_opener(self, name):
        """Retrieve an opener for the given protocol

        :param name: name of the opener to open
        :raises `NoOpenerError`: if no opener has been registered of that name

        """
        if name not in self.registry:
            raise NoOpenerError("No opener for %s" % name)
        index = self.registry[name]
        return self.openers[index]

    def add(self, opener):
        """Adds an opener to the registry

        :param opener: a class derived from fs.opener.Opener

        """

        index = len(self.openers)
        self.openers[index] = opener
        for name in opener.names:
            self.registry[name] = index

    def parse(self, fs_url, default_fs_name=None, writeable=False, create_dir=False, cache_hint=True):
        """Parses a FS url and returns an fs object a path within that FS object
        (if indicated in the path). A tuple of (<FS instance>, <path>) is returned.

        :param fs_url: an FS url
        :param default_fs_name: the default FS to use if none is indicated (defaults is OSFS)
        :param writeable: if True, a writeable FS will be returned
        :param create_dir: if True, then the directory in the FS will be created

        """

        orig_url = fs_url
        match = self.split_segments(fs_url)

        if match:
            fs_name, credentials, url1, url2, path = match.groups()
            if credentials:
                fs_url = '%s@%s' % (credentials, url1)
            else:
                fs_url = url2
            path = path or ''
            fs_url = fs_url or ''
            if ':' in fs_name:
                fs_name, sub_protocol = fs_name.split(':', 1)
                fs_url = '%s://%s' % (sub_protocol, fs_url)
            if '!' in path:
                paths = path.split('!')
                path = paths.pop()
                fs_url = '%s!%s' % (fs_url, '!'.join(paths))

            fs_name = fs_name or self.default_opener
        else:
            fs_name = default_fs_name or self.default_opener
            fs_url = _expand_syspath(fs_url)
            path = ''

        fs_name,  fs_name_params = _parse_name(fs_name)
        opener = self.get_opener(fs_name)

        if fs_url is None:
            raise OpenerError("Unable to parse '%s'" % orig_url)

        fs, fs_path = opener.get_fs(self, fs_name, fs_name_params, fs_url, writeable, create_dir)
        fs.cache_hint(cache_hint)

        if fs_path and iswildcard(fs_path):
            pathname, resourcename = pathsplit(fs_path or '')
            if pathname:
                fs = fs.opendir(pathname)
            return fs, resourcename

        fs_path = join(fs_path, path)

        if create_dir and fs_path:
            if not fs.getmeta('read_only', False):
                fs.makedir(fs_path, allow_recreate=True)

        pathname, resourcename = pathsplit(fs_path or '')
        if pathname and resourcename:
            fs = fs.opendir(pathname)
            fs_path = resourcename

        return fs, fs_path or ''

    def open(self, fs_url, mode='r', **kwargs):
        """Opens a file from a given FS url

        If you intend to do a lot of file manipulation, it would likely be more
        efficient to do it directly through the an FS instance (from `parse` or
        `opendir`). This method is fine for one-offs though.

        :param fs_url: a FS URL, e.g. ftp://ftp.mozilla.org/README
        :param mode: mode to open file file
        :rtype: a file

        """

        writeable = 'w' in mode or 'a' in mode or '+' in mode
        fs, path = self.parse(fs_url, writeable=writeable)
        file_object = fs.open(path, mode)

        file_object = _FSClosingFile(fs, file_object, mode)
        #file_object.fs = fs
        return file_object

    def getcontents(self, fs_url, mode='rb', encoding=None, errors=None, newline=None):
        """Gets the contents from a given FS url (if it references a file)

        :param fs_url: a FS URL e.g. ftp://ftp.mozilla.org/README

        """
        fs, path = self.parse(fs_url)
        return fs.getcontents(path, mode, encoding=encoding, errors=errors, newline=newline)

    def opendir(self, fs_url, writeable=True, create_dir=False):
        """Opens an FS object from an FS URL

        :param fs_url: an FS URL e.g. ftp://ftp.mozilla.org
        :param writeable: set to True (the default) if the FS must be writeable
        :param create_dir: create the directory references by the FS URL, if
            it doesn't already exist

        """
        fs, path = self.parse(fs_url, writeable=writeable, create_dir=create_dir)
        if path and '://' not in fs_url:
            # A shortcut to return an OSFS rather than a SubFS for os paths
            #return OSFS(fs_url)
            print("error, modified file opener.py, check")
        if path:
            fs = fs.opendir(path)
        return fs


class Opener(object):
    """The base class for openers

    Opener follow a very simple protocol. To create an opener, derive a class
    from `Opener` and define a classmethod called `get_fs`, which should have the following signature::

        @classmethod
        def get_fs(cls, registry, fs_name, fs_name_params, fs_path, writeable, create_dir):

    The parameters of `get_fs` are as follows:

     * `fs_name` the name of the opener, as extracted from the protocol part of the url,
     * `fs_name_params` reserved for future use
     * `fs_path` the path part of the url
     * `writeable` if True, then `get_fs` must return an FS that can be written to
     * `create_dir` if True then `get_fs` should attempt to silently create the directory references in path

    In addition to `get_fs` an opener class should contain
    two class attributes: names and desc. `names` is a list of protocols that
    list opener will opener. `desc` is an English description of the individual opener syntax.

    """
    pass




class MemOpener(Opener):
    names = ['mem', 'ram']
    desc = """Creates an in-memory filesystem (very fast but contents will disappear on exit).
Useful for creating a fast temporary filesystem for serving or mounting with fsserve or fsmount.
NB: If you user fscp or fsmv to copy/move files here, you are effectively deleting them!

examples:
* mem:// (opens a new memory filesystem)
* mem://foo/bar (opens a new memory filesystem with subdirectory /foo/bar)    """

    @classmethod
    def get_fs(cls, registry, fs_name, fs_name_params, fs_path,  writeable, create_dir):
        from fs.memoryfs import MemoryFS
        memfs = MemoryFS()
        if create_dir:
            memfs = memfs.makeopendir(fs_path)
        return memfs, None


class DebugOpener(Opener):
    names = ['debug']
    desc = """For developers -- adds debugging information to output.

example:
    * debug:ftp://ftp.mozilla.org (displays details of calls made to a ftp filesystem)"""

    @classmethod
    def get_fs(cls, registry, fs_name, fs_name_params, fs_path,  writeable, create_dir):
        from fs.wrapfs.debugfs import DebugFS
        if fs_path:
            fs, _path = registry.parse(fs_path, writeable=writeable, create_dir=create_dir)
            return DebugFS(fs, verbose=False), None
        if fs_name_params == 'ram':
            from fs.memoryfs import MemoryFS
            return DebugFS(MemoryFS(), identifier=fs_name_params, verbose=False), None
        else:
            from fs.tempfs import TempFS
            return DebugFS(TempFS(), identifier=fs_name_params, verbose=False), None


class TempOpener(Opener):
    names = ['temp']
    desc = """Creates a temporary filesystem that is erased on exit.
Probably only useful for mounting or serving.
NB: If you use fscp or fsmv to copy/move files here, you are effectively deleting them!

example:
* temp://"""

    @classmethod
    def get_fs(cls, registry, fs_name, fs_name_params, fs_path,  writeable, create_dir):
        from fs.tempfs import TempFS
        from fs.wrapfs.lazyfs import LazyFS
        fs = LazyFS((TempFS,(),{"identifier":fs_name_params}))
        return fs, fs_path


class S3Opener(Opener):
    names = ['s3']
    desc = """Opens a filesystem stored on Amazon S3 storage
    The environment variables AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY should be set"""

    @classmethod
    def get_fs(cls, registry, fs_name, fs_name_params, fs_path, writeable, create_dir):
        from fs.s3fs import S3FS

        username, password, bucket = _parse_credentials(fs_path)
        path = ''
        if '/' in bucket:
            bucket, path = fs_path.split('/', 1)

        fs = S3FS(bucket,
                  aws_access_key=username or None,
                  aws_secret_key=password or None)

        if path:
            dirpath, resourcepath = pathsplit(path)
            if dirpath:
                fs = fs.opendir(dirpath)
            path = resourcepath

        return fs, path


class TahoeOpener(Opener):
    names = ['tahoe']
    desc = """Opens a Tahoe-LAFS filesystem

    example:
    * tahoe://http://pubgrid.tahoe-lafs.org/uri/URI:DIR2:h5bkxelehowscijdb [...]"""

    @classmethod
    def get_fs(cls, registry, fs_name, fs_name_params, fs_path, writeable, create_dir):
        from fs.contrib.tahoelafs import TahoeLAFS

        if '/uri/' not in fs_path:
            raise OpenerError("""Tahoe-LAFS url should be in the form <url>/uri/<dicap>""")

        url, dircap = fs_path.split('/uri/')
        path = ''
        if '/' in dircap:
            dircap, path = dircap.split('/', 1)

        fs = TahoeLAFS(dircap, webapi=url)

        if '/' in path:
            dirname, _resourcename = pathsplit(path)
            if create_dir:
                fs = fs.makeopendir(dirname)
            else:
                fs = fs.opendir(dirname)
            path = ''

        return fs, path


class DavOpener(Opener):
    names = ['dav']
    desc = """Opens a WebDAV server

example:
* dav://example.org/dav"""

    @classmethod
    def get_fs(cls, registry, fs_name, fs_name_params, fs_path, writeable, create_dir):
        from fs.contrib.davfs import DAVFS

        url = fs_path

        if '://' not in url:
            url = 'http://' + url

        scheme, url = url.split('://', 1)

        username, password, url = _parse_credentials(url)

        credentials = None
        if username or password:
            credentials = {}
            if username:
                credentials['username'] = username
            if password:
                credentials['password'] = password

        url = '%s://%s' % (scheme, url)

        fs = DAVFS(url, credentials=credentials)

        return fs, ''

class HTTPOpener(Opener):
    names = ['http', 'https']
    desc = """HTTP file opener. HTTP only supports reading files, and not much else.

example:
* http://www.example.org/index.html"""

    @classmethod
    def get_fs(cls, registry, fs_name, fs_name_params, fs_path, writeable, create_dir):
        from fs.httpfs import HTTPFS
        if '/' in fs_path:
            dirname, resourcename = fs_path.rsplit('/', 1)
        else:
            dirname = fs_path
            resourcename = ''
        fs = HTTPFS('http://' + dirname)
        return fs, resourcename

class UserDataOpener(Opener):
    names = ['appuserdata', 'appuser']
    desc = """Opens a filesystem for a per-user application directory.

The 'domain' should be in the form <author name>:<application name>.<version> (the author name and version are optional).

example:
* appuserdata://myapplication
* appuserdata://examplesoft:myapplication
* appuserdata://anotherapp.1.1
* appuserdata://examplesoft:anotherapp.1.3"""

    FSClass = 'UserDataFS'

    @classmethod
    def get_fs(cls, registry, fs_name, fs_name_params, fs_path, writeable, create_dir):
        import fs.appdirfs
        fs_class = getattr(fs.appdirfs, cls.FSClass)
        if ':' in fs_path:
            appauthor, appname = fs_path.split(':', 1)
        else:
            appauthor = None
            appname = fs_path

        if '/' in appname:
            appname, path = appname.split('/', 1)
        else:
            path = ''

        if '.' in appname:
            appname, appversion = appname.split('.', 1)
        else:
            appversion = None

        fs = fs_class(appname, appauthor=appauthor, version=appversion, create=create_dir)

        if '/' in path:
            subdir, path = path.rsplit('/', 1)
            if create_dir:
                fs = fs.makeopendir(subdir, recursive=True)
            else:
                fs = fs.opendir(subdir)

        return fs, path

class SiteDataOpener(UserDataOpener):
    names = ['appsitedata', 'appsite']

    desc = """Opens a filesystem for an application site data directory.

The 'domain' should be in the form <author name>:<application name>.<version> (the author name and version are optional).

example:
* appsitedata://myapplication
* appsitedata://examplesoft:myapplication
* appsitedata://anotherapp.1.1
* appsitedata://examplesoft:anotherapp.1.3"""

    FSClass = 'SiteDataFS'

class UserCacheOpener(UserDataOpener):
    names = ['appusercache', 'appcache']

    desc = """Opens a filesystem for an per-user application cache directory.

The 'domain' should be in the form <author name>:<application name>.<version> (the author name and version are optional).

example:
* appusercache://myapplication
* appusercache://examplesoft:myapplication
* appusercache://anotherapp.1.1
* appusercache://examplesoft:anotherapp.1.3"""

    FSClass = 'UserCacheFS'


class UserLogOpener(UserDataOpener):
    names = ['appuserlog', 'applog']

    desc = """Opens a filesystem for an application site data directory.

The 'domain' should be in the form <author name>:<application name>.<version> (the author name and version are optional).

example:
* appuserlog://myapplication
* appuserlog://examplesoft:myapplication
* appuserlog://anotherapp.1.1
* appuserlog://examplesoft:anotherapp.1.3"""

    FSClass = 'UserLogFS'


class MountOpener(Opener):
    names = ['mount']
    desc = """Mounts other filesystems on a 'virtual' filesystem

The path portion of the FS URL should be a path to an ini file, where the keys are the mount point, and the values are FS URLs to mount.

The following is an example of such an ini file:

    [fs]
    resources=appuser://myapp/resources
    foo=~/foo
    foo/bar=mem://

    [fs2]
    bar=~/bar

example:
* mount://fs.ini
* mount://fs.ini!resources
* mount://fs.ini:fs2"""

    @classmethod
    def get_fs(cls, registry, fs_name, fs_name_params, fs_path, writeable, create_dir):

        from fs.mountfs import MountFS
        from ConfigParser import ConfigParser
        cfg = ConfigParser()

        if '#' in fs_path:
            path, section = fs_path.split('#', 1)
        else:
            path = fs_path
            section = 'fs'

        cfg.readfp(registry.open(path))

        mount_fs = MountFS()
        for mount_point, mount_path in cfg.items(section):
            mount_fs.mount(mount_point, registry.opendir(mount_path, create_dir=create_dir))
        return mount_fs, ''


class MultiOpener(Opener):
    names = ['multi']
    desc = """Combines other filesystems in to a single filesystem.

The path portion of the FS URL should be a path to an ini file, where the keys are the mount point, and the values are FS URLs to mount.

The following is an example of such an ini file:

    [templates]
    dir1=templates/foo
    dir2=templates/bar

example:
* multi://fs.ini"""

    @classmethod
    def get_fs(cls, registry, fs_name, fs_name_params, fs_path, writeable, create_dir):

        from fs.multifs import MultiFS
        from ConfigParser import ConfigParser
        cfg = ConfigParser()

        if '#' in fs_path:
            path, section = fs_path.split('#', 1)
        else:
            path = fs_path
            section = 'fs'

        cfg.readfp(registry.open(path))

        multi_fs = MultiFS()
        for name, fs_url in cfg.items(section):
            multi_fs.addfs(name, registry.opendir(fs_url, create_dir=create_dir))
        return multi_fs, ''


opener = OpenerRegistry([MemOpener,
                         DebugOpener,
                         TempOpener,
                         S3Opener,
                         TahoeOpener,
                         DavOpener,
                         HTTPOpener,
                         UserDataOpener,
                         SiteDataOpener,
                         UserCacheOpener,
                         UserLogOpener,
                         MountOpener,
                         MultiOpener
                         ])

fsopen = opener.open
fsopendir = opener.opendir

